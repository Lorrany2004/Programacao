{
    var x = "Lorrany";
    var y = "18 anos";
    document.write (x +"<br>" + y + "<br>");
    
    var x = "Gabriel"
    var y = "22 anos"
    document.write (x +"<br>" + y + "<br>");

    var x = "Ramom"
    var y = "29 anos"
    document.write (x +"<br>" + y + "<br>");

}